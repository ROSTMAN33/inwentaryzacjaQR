# Spis Sprzętu (Android)

Aplikacja na Androida do rejestrowania wyposażenia przypisanego do użytkownika. W formularzu wpisz imię i nazwisko, wybierz rodzaj sprzętu, a następnie skanuj numery seryjne kolejnych urządzeń. Jeśli skaner nie odczyta etykiety, numer seryjny można wpisać ręcznie. Tabela i eksport CSV/XLSX mają podstawowe kolumny: imię, nazwisko, wybrany sprzęt i SN. Przed spisem możesz też dodać własne kolumny; ich komórki uzupełnia się w tabeli po skanowaniu. Typ kodu (QR, kreskowy lub wpis ręczny) jest wyświetlany na końcu.

Odczyty są zapisywane lokalnie na telefonie.

## Budowanie

Najpierw uruchom `npm install` i `npx cap sync android`, a potem otwórz folder `android` w Android Studio. Wymagany jest Android SDK 36 i JDK 21. Z terminala w folderze `android` można uruchomić `gradlew.bat assembleDebug`; wynik APK znajdzie się w `android/app/build/outputs/apk/debug/app-debug.apk`.

Aplikacja używa kodu bazowego AssetSnap IT Lens, licencja MIT. Zmodyfikowany formularz przypisuje skany do użytkownika i kategorii sprzętu, a surową wartość skanu zapisuje jako numer seryjny.

