# Spis Sprzętu (Android)

Aplikacja na Androida do rejestrowania wyposażenia przypisanego do użytkownika. W formularzu wpisz imię i nazwisko, wybierz rodzaj sprzętu, a następnie skanuj numery seryjne kolejnych urządzeń. Odczyty są zapisywane lokalnie na telefonie. Dane można eksportować do CSV lub XLSX.

## Budowanie

Otwórz folder `android` w Android Studio. Wymagany jest Android SDK 36 i JDK 17. Z terminala w folderze `android` można uruchomić `gradlew.bat assembleDebug`; wynik APK znajdzie się w `android/app/build/outputs/apk/debug/app-debug.apk`.

Aplikacja używa kodu bazowego AssetSnap IT Lens, licencja MIT. Zmodyfikowany formularz przypisuje skany do użytkownika i kategorii sprzętu, a surową wartość skanu zapisuje jako numer seryjny.
